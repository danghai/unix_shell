#undef __STDC__
#include <fcntl.h>
#define __STDC__ 1
