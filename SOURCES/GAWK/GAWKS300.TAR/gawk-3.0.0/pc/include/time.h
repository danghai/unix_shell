#undef __STDC__
#include <time.h>
#define __STDC__ 1
