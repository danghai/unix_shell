/* <dirent.h> based on BSD <sys/dir.h> */

#include <sys/dir.h>
#define dirent direct

