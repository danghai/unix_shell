/* ANSI utility functions */

/* $Header: stdlib.h,v 1.1 88/03/09 21:52:59 egisin Locked $ */

#if ! _STDLIB_H
#define	_STDLIB_H 1

#include <stddef.h>

double	atof ARGS((const char *s));
int	atoi ARGS((const char *s));
long	atol ARGS((const char *s));
double	strtod ARGS((const char *s, char **));
long	strtol ARGS((const char *s, char **, int base));
unsigned long	strtoul ARGS((const char *s, char **, int base));
int	rand ARGS((void));
void	srand ARGS((unsigned int seed));
Void   *malloc ARGS((size_t size));
Void   *realloc ARGS((void *ptr, size_t size));
Void   *calloc ARGS((size_t n, size_t size));
void	free ARGS((void *ptr));
void	abort ARGS((void));
int	atexit ARGS((void (*func)(void)));
void	exit ARGS((int status));
char   *getenv ARGS((const char *name));
int	system ARGS((const char *cmd));
void   *bsearch ARGS ((const void *key, const void *base, size_t n, size_t size,
		       int (*compar)(const void *, const void *)));
void   *qsort ARGS ((const void *base, size_t n, size_t size,
		     int (*compar)(const void *, const void *)));
#define	abs(a)	((a) < 0 : -(a) : (a))

#endif

