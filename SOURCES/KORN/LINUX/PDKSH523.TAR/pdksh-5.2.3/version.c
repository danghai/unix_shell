/*
 * value of $KSH_VERSION (or $SH_VERSION)
 */

char ksh_version [] =
	"@(#)PD KSH v5.2.3 95/06/15";
