UXUTL23c.zip		1 September 94

This is a new set of UNIX utilities for use with MS Shell 2.x.  It fixes a
number of bugs in the earlier release (2.2).  The documentation is minimal
(in true UNIX style, and even worst that UNIX) and assumes that you are
familiar with the original UNIX command set.  The usage file list the
command usage and the meaning of the switches.  If you want more detail, I
recommend the appropriate UNIX manual pages.  The command set has move
towards conforming with X/Open, POSIX etc.

This is file 3 of 4.  The full file set is

    uxutl23a.zip
    uxutl23b.zip
    uxutl23c.zip
    uxutl23d.zip

Refer to the documentation in uxutl23a.zip.

Ian Stewartson.
