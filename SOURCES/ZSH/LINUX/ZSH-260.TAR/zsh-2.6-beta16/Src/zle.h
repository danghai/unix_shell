/*
 * $Id: zle.h,v 1.10 1995/11/16 08:03:57 coleman Exp coleman $
 *
 * zle.h - header file for line editor
 *
 * This file is part of zsh, the Z shell.
 *
 * Copyright (c) 1992-1995 Paul Falstad
 * All rights reserved.
 *
 * Permission is hereby granted, without written agreement and without
 * license or royalty fees, to use, copy, modify, and distribute this
 * software and its documentation for any purpose, provided that the
 * above copyright notice and the following two paragraphs appear in
 * all copies of this software.
 *
 * In no event shall Paul Falstad or the Zsh Development Group be liable
 * to any party for direct, indirect, special, incidental, or consequential
 * damages arising out of the use of this software and its documentation,
 * even if Paul Falstad and the Zsh Development Group have been advised of
 * the possibility of such damage.
 *
 * Paul Falstad and the Zsh Development Group specifically disclaim any
 * warranties, including, but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose.  The software
 * provided hereunder is on an "as is" basis, and Paul Falstad and the
 * Zsh Development Group have no obligation to provide maintenance,
 * support, updates, enhancements, or modifications.
 *
 */

#ifdef ZLEGLOBALS
#define ZLEXTERN
#else
#define ZLEXTERN extern
#endif

#ifdef ZLE

/* cursor position */
ZLEXTERN int cs;

/* line length */
ZLEXTERN int ll;

/* size of line buffer */
ZLEXTERN int linesz;

/* location of mark */
ZLEXTERN int mark;

/* last character pressed */
ZLEXTERN int c;

/* the z_ binding id for this key */
ZLEXTERN int bindk;

/* command argument */
ZLEXTERN int mult;

/* insert mode/overwrite mode flag */
ZLEXTERN int insmode;

/* cost of last update */
#ifdef HAVE_SELECT
ZLEXTERN int cost;

#endif

/* number of lines displayed */
ZLEXTERN int nlnct;

/* most lines of the buffer we've shown at once with the current list showing.
== 0 if there is no list.  == -1 if a new list has just been put on the screen.
== -2 if refresh() needs to put up a new list. */
ZLEXTERN int showinglist;

/* flags associated with last command */
ZLEXTERN int lastcmd;

/* column position before last LINEMOVE movement */
ZLEXTERN int lastcol;

/* != 0 if we're getting a vi range */
ZLEXTERN int virangeflag;

/* kludge to get cw and dw to work right */
ZLEXTERN int wordflag;

/* != 0 if we're killing lines into a buffer, vi-style */
ZLEXTERN int vilinerange;

#endif

/* last named command done */
ZLEXTERN int lastnamed;

/* != 0 if we're done editing */
ZLEXTERN int done;

/* current history line number */
ZLEXTERN int histline;

/* != 0 if we need to call resetvideo() */
ZLEXTERN int resetneeded;

/* != 0 if the line editor is active */
ZLEXTERN int zleactive;

/* the line buffer */
ZLEXTERN unsigned char *line;

/* the cut buffer */
ZLEXTERN char *cutbuf;

/* != 0 if the cut buffer contains a sequence of lines */
ZLEXTERN int linecutbuf;

/* left prompt and right prompt */
ZLEXTERN char *lpmpt, *rpmpt;

/* the last line in the history (the current one) */
ZLEXTERN char *curhistline;

/* the status line */
ZLEXTERN char *statusline;

/* !=0 if a complete added a suffix at the end of a completion */
ZLEXTERN int addedsuffix;

/* 1 if we expect special keys after completing a parameter name */
ZLEXTERN int complexpect;

/*
	the current history line and cursor position for the top line
	on the buffer stack
*/

ZLEXTERN int stackhist, stackcs;

/* != 0 if we are in the middle of a menu completion */
ZLEXTERN int menucmp;

/* != 0 if we are making undo records */
ZLEXTERN int undoing;

/* != 0 if executing a shell function called from zle */
ZLEXTERN int inzlefunc;

/* last vi change buffer */
ZLEXTERN int vichgbufsz, vichgbufptr, vichgflag;
ZLEXTERN char *vichgbuf;

/* point where vi insert mode was last entered */
ZLEXTERN int viinsbegin;

/* != 0 if an argument has been given for this command */
ZLEXTERN int gotmult;

/* != 0 if a kill buffer has been given for this command */
ZLEXTERN int gotvibufspec;

typedef void bindfunc _((void));
typedef bindfunc *F;

struct key {
    struct hashnode *next;
    char *nam;			/* hash data */
    int flags;			/* CURRENTLY UNUSED */
    int func;			/* function code for this key */
    char *str;			/* string corresponding to this key,
			   	 * if func = z_sendstring */
    int len;			/* length of string */
    int prefixct;		/* number of strings for which this is a prefix */
};

struct zlecmd {
    char *name;			/* name of function */
    F func;			/* handler function */
    int flags;
};

/* undo event */

struct undoent {
    int pref;			/* number of initial chars unchanged */
    int suff;			/* number of trailing chars unchanged */
    int len;			/* length of changed chars */
    int cs;			/* cursor pos before change */
    char *change;		/* NOT null terminated */
};

#define UNDOCT 64

ZLEXTERN struct undoent undos[UNDOCT];

/* the line before last mod (for undo purposes) */
ZLEXTERN unsigned char *lastline;

/* buffer specified with "x */
ZLEXTERN int vibufspec;

ZLEXTERN int undoct, lastcs;

ZLEXTERN char *visrchstr;
ZLEXTERN int visrchsense;

#define ZLE_MOVEMENT	(1<<0)
#define ZLE_MENUCMP	(1<<1)
#define ZLE_UNDO	(1<<2)
#define ZLE_YANK	(1<<3)
#define ZLE_LINEMOVE	(1<<4)
#define ZLE_ARG		(1<<5)
#define ZLE_KILL	(1<<6)
#define ZLE_HISTSEARCH	(1<<7)
#define ZLE_NEGARG	(1<<8)
#define ZLE_INSERT	(1<<9)
#define ZLE_DELETE	(1<<10)
#define ZLE_DIGIT	(1<<11)

typedef struct key *Key;

ZLEXTERN int *bindtab, *mainbindtab;
extern int emacsbind[], viinsbind[], vicmdbind[];
ZLEXTERN int altbindtab[256];

#define KRINGCT 8
ZLEXTERN char *kring[KRINGCT];
ZLEXTERN int kringnum;
ZLEXTERN char *vibuf[36];
ZLEXTERN char vilinebuf[36];

#define z_acceptandhold 0
#define z_acceptandinfernexthistory 1
#define z_acceptandmenucomplete 2
#define z_acceptline 3
#define z_acceptlineanddownhistory 4
#define z_backwardchar 5
#define z_backwarddeletechar 6
#define z_backwarddeleteword 7
#define z_backwardkillline 8
#define z_backwardkillword 9
#define z_backwardword 10
#define z_beginningofbufferorhistory 11
#define z_beginningofhistory 12
#define z_beginningofline 13
#define z_beginningoflinehist 14
#define z_capitalizeword 15
#define z_clearscreen 16
#define z_completeword 17
#define z_copyprevword 18
#define z_copyregionaskill 19
#define z_deletechar 20
#define z_deletecharorlist 21
#define z_deleteword 22
#define z_digitargument 23
#define z_downcaseword 24
#define z_downhistory 25
#define z_downlineorhistory 26
#define z_endofbufferorhistory 27
#define z_endofhistory 28
#define z_endofline 29
#define z_endoflinehist 30
#define z_exchangepointandmark 31
#define z_executelastnamedcmd 32
#define z_executenamedcmd 33
#define z_expandhistory 34
#define z_expandorcomplete 35
#define z_expandword 36
#define z_forwardchar 37
#define z_forwardword 38
#define z_getline 39
#define z_gosmacstransposechars 40
#define z_historyincrementalsearchbackward 41
#define z_historyincrementalsearchforward 42
#define z_historysearchbackward 43
#define z_historysearchforward 44
#define z_infernexthistory 45
#define z_insertlastword 46
#define z_killbuffer 47
#define z_killline 48
#define z_killregion 49
#define z_killwholeline 50
#define z_listchoices 51
#define z_listexpand 52
#define z_magicspace 53
#define z_menucompleteword 54
#define z_menuexpandorcomplete 55
#define z_overwritemode 56
#define z_pushline 57
#define z_quotedinsert 58
#define z_quoteline 59
#define z_quoteregion 60
#define z_redisplay 61
#define z_reversemenucomplete 62
#define z_runhelp 63
#define z_selfinsert 64
#define z_selfinsertunmeta 65
#define z_sendbreak 66
#define z_sendstring 67
#define z_sequenceleadin 68
#define z_setmarkcommand 69
#define z_spellword 70
#define z_transposechars 71
#define z_transposewords 72
#define z_undefinedkey 73
#define z_undo 74
#define z_universalargument 75
#define z_upcaseword 76
#define z_uphistory 77
#define z_uplineorhistory 78
#define z_viaddeol 79
#define z_viaddnext 80
#define z_vibackwardblankword 81
#define z_vibackwardchar 82
#define z_vibackwarddeletechar 83
#define z_vibeginningofline 84
#define z_vicapslockpanic 85
#define z_vichange 86
#define z_vichangeeol 87
#define z_vichangewholeline 88
#define z_vicmdmode 89
#define z_videlete 90
#define z_videletechar 91
#define z_vidigitorbeginningofline 92
#define z_viendofline 93
#define z_vifetchhistory 94
#define z_vifindnextchar 95
#define z_vifindnextcharskip 96
#define z_vifindprevchar 97
#define z_vifindprevcharskip 98
#define z_vifirstnonblank 99
#define z_viforwardblankword 100
#define z_viforwardblankwordend 101
#define z_viforwardchar 102
#define z_viforwardwordend 103
#define z_vigotocolumn 104
#define z_vigotomark 105
#define z_vigotomarkline 106
#define z_vihistorysearchbackward 107
#define z_vihistorysearchforward 108
#define z_viindent 109
#define z_viinsert 110
#define z_viinsertbol 111
#define z_vijoin 112
#define z_vimatchbracket 113
#define z_viopenlineabove 114
#define z_viopenlinebelow 115
#define z_vioperswapcases 116
#define z_viputafter 117
#define z_virepeatchange 118
#define z_virepeatfind 119
#define z_virepeatsearch 120
#define z_vireplace 121
#define z_vireplacechars 122
#define z_virevrepeatfind 123
#define z_virevrepeatsearch 124
#define z_visetbuffer 125
#define z_visetmark 126
#define z_visubstitute 127
#define z_viswapcase 128
#define z_viundochange                   129
#define z_viunindent                     130
#define z_viyank                         131
#define z_viyankeol                      132
#define z_whichcommand                   133
#define z_yank                           134
#define z_yankpop                        135
#define z_emacsbackwardword              136
#define z_emacsforwardword               137
#define z_killword                       138
#define z_vikillline                     139
#define z_vibackwardkillword             140
#define z_expandcmdpath                  141
#define z_negargument                    142
#define z_poundinsert                    143
#define z_viforwardword                  144
#define z_vibackwardword                 145
#define z_uplineorsearch                 146
#define z_downlineorsearch               147
#define z_pushinput                      148
#define z_pushpopinput                   149
#define z_historybeginningsearchbackward 150
#define z_historybeginningsearchforward  151
#define z_expandorcompleteprefix         152
#define z_describekeybriefly             153
#define z_whereis                        154
#define z_vikilleol                      155
#define z_viyankwholeline                156
#define z_viputbefore                    157
#define z_vipoundinsert                  158
#define z_viuplineorhistory              159
#define z_vidownlineorhistory            160
#define ZLECMDCOUNT                      161

extern struct zlecmd zlecmds[];
